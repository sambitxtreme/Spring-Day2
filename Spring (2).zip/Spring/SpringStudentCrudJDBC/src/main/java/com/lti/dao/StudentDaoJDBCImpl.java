package com.lti.dao;

import org.springframework.jdbc.core.JdbcTemplate;

import com.lti.model.Student;

public class StudentDaoJDBCImpl implements StudentDao {
   private JdbcTemplate jdbcTemplate;
   
   private static final String CREATE_STUDENT="Insert into Student(Roll_number,Student_Name,Student_Score) values (?,?,?)";
	@Override
	public int createStudent(Student student) {
	int result=jdbcTemplate.update(CREATE_STUDENT,student.getRollNumber(),student.getStudentName(),student.getStudentScore());
		return result;
	}

	@Override
	public Student readStudentByRollNumber(int rollNumber) {
	
		return null;
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	

}
